-- ============================================================
--  COMPETITION TRACKER — SUPABASE SCHEMA
--  Run this in your Supabase SQL Editor (Dashboard → SQL Editor)
-- ============================================================

-- ============================================================
-- VISITORS TABLE
-- Every page load creates a visitor record
-- ============================================================
create table public.visitors (
  id                uuid        default gen_random_uuid() primary key,
  created_at        timestamptz default now() not null,

  -- Session
  session_id        text,
  fingerprint       text,

  -- Network / IP info  (from ipapi.co)
  ip_address        text,
  ip_country        text,
  ip_country_code   text,
  ip_region         text,
  ip_city           text,
  ip_isp            text,
  ip_lat            double precision,
  ip_lng            double precision,
  ip_timezone       text,

  -- GPS  (from navigator.geolocation)
  gps_status        text   default 'pending',   -- pending | granted | denied | error
  gps_lat           double precision,
  gps_lng           double precision,
  gps_accuracy      double precision,

  -- Device (parsed from User-Agent + navigator APIs)
  user_agent        text,
  browser           text,
  browser_version   text,
  os                text,
  os_version        text,
  device_type       text,                        -- mobile | tablet | desktop
  device_brand      text,
  screen_width      integer,
  screen_height     integer,
  language          text,
  languages         text,
  timezone          text,
  cpu_cores         integer,
  device_memory     text,
  platform          text,
  touch_points      integer,
  referrer          text,

  -- Eligibility
  is_eligible       boolean default false,
  eligibility_reason text,
  has_registered    boolean default false
);

-- ============================================================
-- CONTESTANTS TABLE
-- Users who completed the registration form
-- ============================================================
create table public.contestants (
  id                    uuid        default gen_random_uuid() primary key,
  created_at            timestamptz default now() not null,

  -- Link to visitor
  visitor_id            uuid        references public.visitors(id) on delete set null,

  -- Submitted info
  full_name             text        not null,
  email                 text        not null,
  phone                 text        not null,
  date_of_birth         date        not null,

  -- Context at registration time
  ip_address            text,
  ip_country            text,
  ip_city               text,
  ip_isp                text,
  gps_lat               double precision,
  gps_lng               double precision,
  device_type           text,
  browser               text,
  os                    text,
  fingerprint           text,

  -- Status flags
  is_eligible           boolean  default true,
  is_duplicate          boolean  default false,
  is_winner             boolean  default false,
  is_disqualified       boolean  default false,
  disqualification_reason text,

  -- Admin use
  admin_notes           text,
  reviewed_at           timestamptz,

  -- Prevent exact duplicates
  constraint unique_email unique (email),
  constraint unique_phone unique (phone)
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.visitors    enable row level security;
alter table public.contestants enable row level security;

-- Anonymous (public page): INSERT only on visitors
create policy "anon_insert_visitors"
  on public.visitors for insert
  to anon with check (true);

-- Anonymous: UPDATE own visitor row (for GPS update)
create policy "anon_update_visitors"
  on public.visitors for update
  to anon using (true) with check (true);

-- Anonymous: INSERT contestants (register)
create policy "anon_insert_contestants"
  on public.contestants for insert
  to anon with check (true);

-- Authenticated admin: full access to everything
create policy "admin_all_visitors"
  on public.visitors for all
  to authenticated using (true) with check (true);

create policy "admin_all_contestants"
  on public.contestants for all
  to authenticated using (true) with check (true);

-- ============================================================
-- INDEXES  (performance for the admin dashboard queries)
-- ============================================================
create index idx_visitors_created_at   on public.visitors(created_at desc);
create index idx_visitors_ip           on public.visitors(ip_address);
create index idx_visitors_session      on public.visitors(session_id);
create index idx_visitors_gps_status   on public.visitors(gps_status);
create index idx_visitors_eligible     on public.visitors(is_eligible);

create index idx_contestants_created_at on public.contestants(created_at desc);
create index idx_contestants_email      on public.contestants(email);
create index idx_contestants_phone      on public.contestants(phone);
create index idx_contestants_ip         on public.contestants(ip_address);
create index idx_contestants_winner     on public.contestants(is_winner);

-- ============================================================
-- DONE — Now create your admin user:
--   Supabase Dashboard → Authentication → Users → Add User
--   Use that email/password to log into admin.html
-- ============================================================
