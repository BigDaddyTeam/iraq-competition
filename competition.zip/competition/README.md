# 🏆 Iraq Competition Tracker
### Full-stack giveaway site with admin dashboard, GPS verification & analytics

---

## What's Included

| File | Purpose |
|------|---------|
| `index.html` | Public registration page (the link you share) |
| `admin/index.html` | Admin dashboard (private) |
| `supabase-schema.sql` | Database setup |
| `vercel.json` | Routing config for Vercel |

**Public page collects:** GPS coordinates, IP address, device/browser/OS info  
**Contestants submit:** Name, email, phone, date of birth  
**Admin sees:** All of the above, live map, stats, export CSV, mark winners

---

## STEP 1 — Create a Supabase Project (Free)

1. Go to **https://supabase.com** → Sign Up (free)
2. Click **"New Project"** → give it a name (e.g. `competition`)
3. Choose a **region** close to Iraq (e.g. Europe West or Asia)
4. Set a strong **database password** — save it somewhere
5. Wait ~2 minutes for it to provision

---

## STEP 2 — Run the Database Schema

1. In your Supabase project → click **SQL Editor** (left sidebar)
2. Click **"New Query"**
3. Copy the entire contents of `supabase-schema.sql`
4. Paste it and click **Run** (▶)
5. You should see "Success. No rows returned."

---

## STEP 3 — Create Your Admin Account

1. In Supabase → go to **Authentication → Users**
2. Click **"Add User" → "Create New User"**
3. Enter your admin email and a strong password
4. Click **Create User**

> This is the email/password you'll use to log into `admin/index.html`

---

## STEP 4 — Get Your API Keys

1. In Supabase → go to **Settings → API** (left sidebar)
2. Copy:
   - **Project URL** (looks like `https://abcxyz123.supabase.co`)
   - **anon / public key** (long JWT string starting with `eyJ...`)

---

## STEP 5 — Add Keys to HTML Files

Open **both** `index.html` and `admin/index.html` and replace the placeholders at the top of each `<script>` block:

```javascript
const SUPABASE_URL      = 'https://YOUR_PROJECT_ID.supabase.co';  // ← paste here
const SUPABASE_ANON_KEY = 'YOUR_ANON_KEY_HERE';                   // ← paste here
```

---

## STEP 6 — Customize the Competition

In `index.html`, you can change:
- **Competition name** — find `"Grand Prize Competition 2025"` and update
- **Closing date** — find `"Competition closes 31 December 2025"` and update
- **Age limit** — find `< 18` in the validation logic if you want a different minimum

---

## STEP 7 — Deploy to Vercel (Free)

**Option A — Drag & Drop (easiest):**
1. Go to **https://vercel.com** → Sign Up (free)
2. Click **"Add New → Project"**
3. Choose **"Deploy without a Git repository"**
4. Drag the entire `competition/` folder onto the page
5. Click **Deploy** — done in ~30 seconds

**Option B — Via GitHub:**
1. Push this folder to a GitHub repo
2. Go to Vercel → Import from GitHub
3. Select the repo → Deploy

**Your URLs will be:**
- `https://your-project.vercel.app/` → Public registration page
- `https://your-project.vercel.app/admin` → Admin dashboard

> **Optional:** Add a custom domain in Vercel → Settings → Domains

---

## STEP 8 — First Login

1. Open `your-site.vercel.app/admin`
2. Sign in with the email/password you created in Step 3
3. You should see the dashboard (empty until people visit)

---

## What the Admin Dashboard Shows

### Overview Tab
- Total page visits
- Unique IP addresses
- GPS granted / denied counts + percentages
- Iraq-eligible visitor count
- Registrations + conversion rate
- 14-day visit trend chart
- GPS permission pie chart
- Device type bar chart

### Visitors Tab
Every person who loaded the page, including:
- Timestamp, IP address, city/country
- ISP/organization (from IP geolocation)
- Browser + version, OS + version, device type + brand
- Screen resolution, language
- GPS status (granted/denied) + exact GPS coordinates
- Whether they registered
- Session ID + browser fingerprint
- *(Click any row for full detail panel)*

### Contestants Tab
Everyone who filled out the form, including:
- All submitted info (name, email, phone, DOB, age)
- IP address + location at time of registration
- GPS coordinates
- Device fingerprint (cross-reference duplicate entries)
- Admin can: mark as Winner 🏆, Disqualify ✕, add private Notes
- Export full list as CSV

### Map Tab
Interactive map (centered on Iraq) with:
- 🔵 Blue pins = visitors (non-registered)
- 🟢 Green pins = contestants
- 🔴 Red pins = ineligible/outside Iraq
- 🟡 Gold pins = winner
- Click any pin for full details

---

## Verifying Winner Legitimacy

To confirm a winner is genuine:
1. Go to **Contestants tab** → click their row
2. Check their **IP Address** — use https://ipinfo.io to confirm it resolves to Iraq
3. Check their **GPS coordinates** — paste into Google Maps to verify Iraq location
4. Check their **ISP** — should be an Iraqi carrier (Zain IQ, Asiacell, Korek, etc.)
5. Check **device fingerprint** — if the same fingerprint appears on another entry, it's a duplicate device

The **fingerprint** field can detect if someone registered twice from the same device even with different emails/phones.

---

## Hosting Note — Free Tier Limits

| Service | Free Limit |
|---------|-----------|
| Vercel | Unlimited static deployments, 100GB bandwidth/mo |
| Supabase | 500MB database, 2GB bandwidth, 50,000 monthly active users |
| ipapi.co (IP lookup) | 1,000 requests/day |

If you expect more than 1,000 visitors/day, upgrade ipapi.co ($10/mo) or switch to `https://ip-api.com` (free but HTTP only — works on Vercel since fetch is server-proxied).

---

## Privacy & Legal Note

Since this site collects personal data (names, emails, GPS location), you should:
- Add a **Privacy Policy** link on the registration page
- State how data is stored and used
- Comply with Iraq's data protection laws and any applicable regulations

---

## Support / Customization Ideas

- Add your logo/competition branding to `index.html`
- Change the competition prize description in the hero section
- Add an Arabic language version (RTL layout)
- Set up a Supabase Edge Function to send confirmation emails
- Add a countdown timer to the closing date
